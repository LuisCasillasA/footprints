/****** Script for SelectTopNRows command from SSMS  ******/
SELECT TOP (1000) [Id]
      ,[Nombre]
      ,[Apellidos]
      ,[Telefono]
      ,[Correo]
      ,[Contraseña]
  FROM [Logins].[dbo].[InicioSesion]